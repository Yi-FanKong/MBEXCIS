#' @title A dataset containing the quantitative trait and the genotype of a SNP with no missing values for mixture data
#'
#' @description The dataset includes 30 pedigrees, 260 pedigree-related individuals and extra 130 unrelated females.
#'
#' @docType data
#' @keywords datasets
#' @name mixture_data1
#' @usage mixture_data1
#' @format
#' \describe{
#' \item{famid}{Pedigree ID.}
#' \item{iid}{Individual ID.}
#' \item{fid}{Father ID.}
#' \item{mid}{Mother ID.}
#' \item{sex}{The genetic sex of the individual, coded as 1 for males and 2 for females, following the PLINK default coding.}
#' \item{type}{The type of data, type=1 for pedigree data; type=2 for unrelated data.}
#' \item{trait}{A numeric variable of the quantitative trait.}
#' \item{genotype}{The genotype of the target SNP, coded as 0, 1 or 2, indicating the number of the minor alleles.}
#' }
NULL
