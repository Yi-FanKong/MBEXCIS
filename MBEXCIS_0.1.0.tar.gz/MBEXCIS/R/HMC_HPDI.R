#' @title A function to obtain the highest posterior density interval of the samples
#'
#' @description A function to obtain the highest posterior density interval of the samples.
#'
#' @usage HMC_HPDI(sampleVec,credMass=0.95)
#'
#' @param sampleVec A vector contains the samples.
#' @param credMass A value between 0 and 1 used to specify the probability of the samples which should be included in an interval, and the default is 0.95.
#'
#' @return A vector contains the lower bound and the upper bound of the highest posterior density interval.
#' @export
#'
#' @author Yi-Fan Kong and Ji-Yuan Zhou
#' @keywords function
#' @examples HMC_HPDI(rnorm(100,1,1),credMass = 0.95)
#'
HMC_HPDI = function( sampleVec , credMass=0.95 ) {
  sortedsam = sort( sampleVec )
  nsamp <- length( sortedsam )
  gap = round( credMass * nsamp )
  nCIs = nsamp - gap
  init <- 1 : nCIs
  inds <- which.min(sortedsam[init + gap] - sortedsam[init])
  HDImin = sortedsam[ inds ]
  HDImax = sortedsam[ inds + gap ]
  HDIlim = c( HDImin , HDImax )
  return( HDIlim )
}
