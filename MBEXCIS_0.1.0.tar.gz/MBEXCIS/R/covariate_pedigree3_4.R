#' @title A dataset containing the covariates for qualitative traits based on pedigree data
#'
#' @description The dataset contains two covariates for 30 pedigrees, 260 pedigree-related individuals.
#'
#' @docType data
#' @keywords datasets
#' @name covariate_pedigree3_4
#' @usage covariate_pedigree3_4
#' @format
#' \describe{
#' \item{famid}{Pedigree ID.}
#' \item{iid}{Individual ID.}
#' \item{fid}{Father ID.}
#' \item{mid}{Mother ID.}
#' \item{sex}{The genetic sex of the individual, coded as 1 for males and 2 for females, following the PLINK default coding.}
#' \item{covariate1}{A quantitative covariate.}
#' \item{covariate2}{A qualitative covariate.}
#' }
NULL
